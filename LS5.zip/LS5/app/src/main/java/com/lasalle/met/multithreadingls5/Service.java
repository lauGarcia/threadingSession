package com.lasalle.met.multithreadingls5;

import android.app.IntentService;
import android.content.Intent;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by FurruPi on 14/1/18.
 */

public class Service extends IntentService {

    protected Messenger messenger;
    protected Message message;

    public Service() {
        super("ServiceName");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("SERVICE","ON");
        message = new Message();
        messenger = intent.getParcelableExtra("Messenger");
        sendMessage();
    }

    private void sendMessage() {
        if (messenger != null){
            message.what = 1;
            message.obj = "Holaaaaaa";
            try {
                messenger.send(message);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }
}
