package com.lasalle.met.multithreadingls5.data;


import com.lasalle.met.multithreadingls5.model.Movie;

import java.util.List;

/**
 * Created by lauGarcia on 02/01/18.
 */
public interface MovieData {
    void addItem(Movie movie);

    List<Movie> getMovieList();

}
