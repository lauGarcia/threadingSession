package com.lasalle.met.multithreadingls5;

import android.app.IntentService;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by FurruPi on 17/1/18.
 */

public class MService extends IntentService {

    public MService(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d("SERVICE","ON");
    }
}
