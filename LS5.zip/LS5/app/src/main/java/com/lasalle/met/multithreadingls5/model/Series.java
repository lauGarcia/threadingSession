package com.lasalle.met.multithreadingls5.model;

import java.io.Serializable;

/**
 * Created by FurruPi on 14/1/18.
 */

public class Series implements Serializable {


}
