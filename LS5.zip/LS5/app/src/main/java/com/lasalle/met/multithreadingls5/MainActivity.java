package com.lasalle.met.multithreadingls5;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;
import com.koushikdutta.ion.Ion;
import com.lasalle.met.multithreadingls5.model.TvShow;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private Button threadButton;
    private Button asyncButton;
    private TextView textViewTitle;
    private Button asyncImageButton;
    private Button asyncDataButton;
    private ImageView imageViewAsync;
    private Button asyncData2Button;

    private ProgressDialog progressDialog;

    private Handler handler;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewTitle = findViewById(R.id.textView_title);
        threadButton = findViewById(R.id.button_thread);
        asyncButton = findViewById(R.id.button_async);
        asyncImageButton = findViewById(R.id.button_async_image);
        imageViewAsync = findViewById(R.id.imageView_async_image);
        asyncDataButton = findViewById(R.id.button_async_data);
        asyncData2Button = findViewById(R.id.button_async_data_2);

        // THREADING *************************************
        // F1 - Para que pete
        /*threadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("THREAD", "On");
                        textViewTitle.setText("Thread 2");
                    }
                });
                thread.start();
            }
        });*/

        // F2 - Sin pete
        threadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("THREAD", "On");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textViewTitle.setText("Thread 2");
                            }
                        });
                    }
                });
                thread.start();
            }
        });

        // ASYNC TASK
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Descargando...");
        progressDialog.setTitle("Progreso");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);

        asyncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MyAsyncTask().execute("http://example.com");
            }
        });

        // ASYNC TASK DOWNLOAD IMAGE
        asyncImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                new DownloadImageTask().execute("http://i0.kym-cdn.com/photos/images/original/000/428/768/8c3.jpg");
            }
        });

        // ASYNC TASK DOWNLOAD DATA
        asyncDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                new DownloadData().execute("https://private-9ae13-met1.apiary-mock.com/series");
                Log.d("ASYNC DOWNLOAD DATA", "");
            }
        });

        asyncData2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    JsonArray jsonArray = Ion.with(getApplicationContext())
                            .load("http://private-8520e-mdpalibrary.apiary-mock.com/shows")
                            .asJsonArray()
                            .get();

                    Log.d("","");
                    Type collectionType = new TypeToken<List<TvShow>>(){}.getType();
                    Gson gson = new Gson();
                    List<TvShow> showList = gson.fromJson(jsonArray, collectionType);

                    gson.fromJson(jsonArray, TvShow.class);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });

        // INTENT SERVICE
        this.handler = new Handler() {
            @Override public void handleMessage(Message msg) {
                super.handleMessage(msg);
                MainActivity.this.handleMessage(msg);
            }
        };

        Messenger messenger = new Messenger(handler);
        Intent intent = new Intent(this, Service.class);
        intent.putExtra("Messenger", messenger);
        startService(intent);

    }

    public void handleMessage(Message msg) {
        if (msg.what == 1) {
            Toast.makeText(this, msg.obj.toString(), Toast.LENGTH_LONG).show();
        }
    }


    // ASYNC TASKS
    private class MyAsyncTask extends AsyncTask<String,Integer,Integer> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setProgress(0);
            progressDialog.setMax(100);
            progressDialog.show();
        }

        @Override
        protected Integer doInBackground(String... strings) {
            // Simulamos que estamos descargando algo mediante un sleep
            for (int i = 0; i < 100; i++){
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                publishProgress(i);
            }
            return 100;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            progressDialog.dismiss();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }
    }

    private class DownloadImageTask extends AsyncTask<String,Void,Bitmap> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            progressDialog.dismiss();
            imageViewAsync.setImageBitmap(bitmap);
        }

        @Override
        protected Bitmap doInBackground(String... strings) {
            Bitmap bitmap = null;
            try {
                URL aURL = new URL(strings[0]);
                Log.d("DEBUG","Descargando imagen: "+aURL);

                URLConnection urlConnection = aURL.openConnection();
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);

                bitmap = BitmapFactory.decodeStream(bufferedInputStream);

                bufferedInputStream.close();
                inputStream.close();

            } catch (IOException e) {
                Log.e("Hub","Error getting the image from server : " + e.getMessage().toString());
                return null;
            }
            return bitmap;
        }
    }

    private class DownloadData extends AsyncTask<String,Void,String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String str) {
            super.onPostExecute(str);
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                // Build the URL to request
                URL urlToRequest = urlToRequest = new URL(strings[0]);
                // Build the connection
                HttpURLConnection connection = (HttpURLConnection) urlToRequest.openConnection();
                // Create the buffer to read the information
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                // Create the object to store the information
                String data = "";
                StringBuilder responseBuilder = new StringBuilder();
                //Read response
                while((data = reader.readLine()) != null) {
                    responseBuilder.append(data);
                }
                // Return the downloaded information to be handled on the main thread
                String dataStr = responseBuilder.toString();
                return responseBuilder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return "";
        }
    }
}
