package com.lasalle.met.multithreadingls5;

import android.app.IntentService;
import android.content.Intent;
import android.support.annotation.Nullable;

/**
 * Created by FurruPi on 17/1/18.
 */

public class Service2 extends IntentService {

    public Service2(String name) {
        super("s2");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

    }
}
