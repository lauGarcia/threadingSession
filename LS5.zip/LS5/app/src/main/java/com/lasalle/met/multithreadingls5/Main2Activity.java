package com.lasalle.met.multithreadingls5;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {

    private Button buttonInitAsync;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        progressDialog = new ProgressDialog(this);

        buttonInitAsync = findViewById(R.id.button_init_async);

        final Intent intent = new Intent(this, Service.class);
        startService(intent);

        buttonInitAsync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //MAsyncTask asyncTask = new MAsyncTask();
                //asyncTask.execute(1);

                startService(intent);

            }
        });


    }

    public class MAsyncTask extends AsyncTask<Integer,Integer,String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setTitle("AsyncTask");
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setMax(10);
            progressDialog.setProgress(0);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Integer... integers) {
            for(int i = 0; i <= 10; i++){
                Log.d("ASYNC TASK", "doInbAckground");
                onProgressUpdate(i);
            }

            return "";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
        }

    }
}
